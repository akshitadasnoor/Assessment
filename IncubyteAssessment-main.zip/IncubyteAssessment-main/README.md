# IncubyteAssessment
**Test Compose Function in Gmail**

Tested the compose function in Gmail to send an email with the body "Automation QA test for Incubyte" and subject "Incubyte" using Selenium Webdriver ,Java and Gherkin in Intellij IDE. 
